 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

 /*
 * Ian Anderson
 * Sensor Subsystem Application Code 
*/

/*
? [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#include "mcc_generated_files/system/system.h"
#include <stdint.h>
#include <stdio.h>

#define start1      0x41
#define start2      0x5A
#define end1        0x59
#define end2        0x42
#define AG          0x61
#define AC          0x63
#define IA          0x69
#define KD          0x6B
#define EE          0x58

#define baro_add        0x77

#define hall_add    0x36

#define rhum_add    0x27
#define wind_speed  0x01
#define temperature 0x02
#define humidity    0x03
#define barometer   0x04

uint8_t msg[65];
uint8_t buffer[2];
uint8_t i = 0;
uint8_t last_i = 0;
uint8_t msg_ii = 0;
uint8_t incoming = 0;
uint8_t msg_complete = 0;
volatile uint16_t time_ms = 0;
volatile uint16_t time_s = 0;

const char err1[] = "wind sensor read error";
const char err2[] = "temperature read error";
const char err3[] = "humidity read error";
const char err4[] = "barometer read error";

//callback function for UART receive
void rxReadyCallback(void) {
    if (EUSART1_IsRxReady() == 1) {
        buffer[i] = EUSART1_Read();//reads fifo

        if (buffer[last_i] == start1 && buffer[i] == start2) { //checks for start bytes
            incoming = 1;
            msg[0] = buffer[last_i];
            msg_ii = 1;
        } else if (buffer[last_i] == end1 && buffer[i] == end2) { //checks for end bytes
            incoming = 0;
            msg[msg_ii] = buffer[i];
            msg_complete = 1;
        } else if (msg_ii >= 64) { //terminates msg if too long
            incoming = 0;
            msg[62] = end1;
            msg[63] = end2;
            msg_complete = 1;
        }

        if (incoming == 1) { //parse incoming msg
            msg[msg_ii] = buffer[i];
            msg_ii++;
        }

        last_i = i;
        i++;
        if (i >=2) {
            i = 0;
        }
    }
}
//callback function for timer
void tmrCallback(void) {
    time_ms += 100;
    if (time_ms >= 1000) {
        time_ms -= 1000;
        time_s++;
    }
}
//function to calculate and return current time  
float getTimeNow(void) {
    float Time = 0.0;
    Time = ((float)time_s * 1.0) + ((float)time_ms / 1000.0);
    return Time;
}
//function to clear msg
void clearString(void) {
    for (int k = 0; k < 64; k++) {
        msg[k] = 0x00;
    }
}
//msg type 1 function
void sendSensorData(uint8_t type, uint16_t data) {
    clearString();
    msg[0] = start1;
    msg[1] = start2;
    msg[2] = IA;
    msg[3] = EE;
    msg[4] = type;
    msg[5] = (data >> 8) & 0xFF;
    msg[6] = (data >> 0) & 0xFF;
    msg[7] = end1;
    msg[8] = end2;
    printf("%s",msg);
}
//msg type 4 function
void sendErrCode(int code) {
    clearString();
    msg[0] = start1;
    msg[1] = start2;
    msg[2] = IA;
    msg[3] = AG;
    msg[4] = (uint8_t)code;
    msg[7] = end1;
    msg[8] = end2;
    printf("%s",msg);
}
//msg type 5 function
void sendErrMsg(int code) {
    clearString();
    switch (code) {
        //wind speed sensor
        case 1:
        msg[0] = start1;
        msg[1] = start2;
        msg[2] = IA;
        msg[3] = AG;
        for (int k = 0; k < strlen(err1); k++) {
            msg[k+4] = (uint8_t)err1[k];
        }
        msg[strlen(err1)+4] = end1;
        msg[strlen(err1)+5] = end2;
        break;
        //temperature sensor 
        case 2:
        msg[0] = start1;
        msg[1] = start2;
        msg[2] = IA;
        msg[3] = AG;
        for (int k = 0; k < strlen(err2); k++) {
            msg[k+4] = (uint8_t)err2[k];
        }
        msg[strlen(err2)+4] = end1;
        msg[strlen(err2)+5] = end2;
        break;
        //humidity sensor
        case 3:
        msg[0] = start1;
        msg[1] = start2;
        msg[2] = IA;
        msg[3] = AG;
        for (int k = 0; k < strlen(err3); k++) {
            msg[k+4] = (uint8_t)err3[k];
        }
        msg[strlen(err3)+4] = end1;
        msg[strlen(err3)+5] = end2;
        break;
        //barometer sensor
        case 4:
        msg[0] = start1;
        msg[1] = start2;
        msg[2] = IA;
        msg[3] = AG;
        for (int k = 0; k < strlen(err4); k++) {
            msg[k+4] = (uint8_t)err4[k];
        }
        msg[strlen(err4)+4] = end1;
        msg[strlen(err4)+5] = end2;
        break;
    }
    printf("%s",msg);
}

int main(void) {
    SYSTEM_Initialize();
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
    EUSART1_ReceiveInterruptEnable();
    EUSART1_RxCompleteCallbackRegister(rxReadyCallback);
    TMR0_OverflowCallbackRegister(tmrCallback);
    
    uint32_t sensorBuffer = 0;
    uint32_t lastSensor = 0;
    uint16_t rhum_val;
    uint16_t baro_val;
    uint16_t wind_val;
    signed short temp_val;
    uint16_t hum_read = 0;
    uint16_t tem_read = 0;
    const uint8_t baro_convert1 = 0x48;
    const uint8_t baro_convert2 = 0x58;
    const uint8_t nullCommand = 0x00;
    uint24_t D1 = 0;
    uint24_t D2 = 0;
    uint24_t d1 = 0;
    uint24_t d2 = 0;
    int32_t dT, TEMP, P;
    int64_t OFF, SENS;
    int T2, OFF2, SENS2;
    int shift = 0;

    uint16_t c1 = 0;//39830;
    uint16_t c2 = 0;//59268;
    uint16_t c3 = 0;//41819;
    uint16_t c4 = 0;//26202;
    uint16_t c5 = 0;//8067;
    uint16_t c6 = 0;//22895;
    
    uint8_t c1_read = 0xA2;
    uint8_t c2_read = 0xA4;
    uint8_t c3_read = 0xA6;
    uint8_t c4_read = 0xA8;
    uint8_t c5_read = 0xAA;
    uint8_t c6_read = 0xAC;

    int newRead = 0;
    float cycleTime = 0.0;
    float currentTime = 0.0;
    
    int windReady = 0;
    uint8_t reg_add = 0x0E;
    uint16_t angle1 = 0;
    uint16_t angle2 = 0;
    float delta1 = 0.0;
    float delta2 = 0.0;
    
    I2C1_Write(baro_add, &c1_read, 1);
    I2C1_Read(baro_add, &c1, 2);
    I2C1_Write(baro_add, &c2_read, 1);
    I2C1_Read(baro_add, &c2, 2);
    I2C1_Write(baro_add, &c3_read, 1);
    I2C1_Read(baro_add, &c3, 2);
    I2C1_Write(baro_add, &c4_read, 1);
    I2C1_Read(baro_add, &c4, 2);
    I2C1_Write(baro_add, &c5_read, 1);
    I2C1_Read(baro_add, &c5, 2);
    I2C1_Write(baro_add, &c6_read, 1);
    I2C1_Read(baro_add, &c6, 2);

    TMR0_Start();
    while(1) {
        currentTime = getTimeNow();
        
        //forward comparator read to motor subsystem
        switch (COMP_IN_GetValue()) {
            case 0:
                led1_SetLow();
                led2_SetHigh();
                SUN_DIR_SetLow();
            break;
            case 1:
                led2_SetLow();
                led1_SetHigh();
                SUN_DIR_SetHigh();
            break;
        }
        
        //sensor polling
        if (currentTime - cycleTime <= 0.1) {
            //start barometer temperature conversion
            I2C1_Write(baro_add, &baro_convert2, 1);
        } else if (currentTime - cycleTime <= 0.2) {
            //read barometer temperature
            I2C1_Write(baro_add, &nullCommand, 1);
            I2C1_Read(baro_add, &D2, 3);
        } else if (currentTime - cycleTime <= 0.3) {
            //start barometer pressure conversion
            I2C1_Write(baro_add, &baro_convert1, 1);
        } else if (currentTime - cycleTime <= 0.4) {
            //read barometer pressure
            I2C1_Write(baro_add, &nullCommand, 1);
            I2C1_Read(baro_add, &D1, 3);
        } else if (currentTime - cycleTime <= 0.5) {
            //start humidity sensor conversion
            I2C1_Write(rhum_add, &nullCommand, 0);
        } else if (currentTime - cycleTime <= 0.6) {
            //read humidity sensor
            I2C1_Read(rhum_add, &sensorBuffer, 4);
        } else if (currentTime - cycleTime <= 0.7) {
            //first wind read
            I2C1_Write(hall_add, &reg_add, 1);
            I2C1_Read(hall_add, &angle1, 2);
            delta1 = getTimeNow();
        } else if (currentTime - cycleTime <= 0.8) {
            I2C1_Write(hall_add, &reg_add, 1);
            I2C1_Read(hall_add, &angle2, 2);
            delta2 = getTimeNow();
            windReady = 1;
            cycleTime = currentTime;
        }

        //sensor broadcast
        switch (newRead) {
            case 0:
            break;
            case 1:
            //wind speed
            sendSensorData(newRead, wind_val);
            newRead = 0;
            break;
            case 2:
            //temperature
            sendSensorData(newRead, temp_val);
            newRead = 0;
            break;
            case 3:
            //humidity
            sendSensorData(newRead, rhum_val);
            newRead = 0;
            break;
            case 4:
            //air pressure
            sendSensorData(newRead, baro_val);
            newRead = 0;
            break;
        }

        //calculate air pressure & temperature
       if (D2 != d2) {
           d2 = D2;
           dT = D2 - (c5 * pow(2,8));
           TEMP = 2000 + ((dT * c6) / pow(2,23));
           if (TEMP < 2000) {
               T2 = pow(dT,2) / 2147483648;
               OFF2 = 3 * pow((TEMP - 2000),2);
               SENS2 = 7 * pow((TEMP - 2000),2) / 8;
               if (TEMP < -1500) {
                   SENS2 = SENS2 + 2 * pow((TEMP + 1500),2);
               }
               TEMP = TEMP - T2;
               shift = 1;
           }
       }
       if (D1 != d1) {
           d1 = D1;
           OFF = c2 * pow(2,16) + (c4 * dT) / pow(2,7);
           SENS = c1 * pow(2,15) + (c3 * dT) / pow(2,8);
           if (shift == 1) {
               OFF = OFF - OFF2;
               SENS = SENS - SENS2;
               shift = 0;
           }
           P = (((D1 * SENS) / pow(2,21)) - OFF) / pow(2,15);
           newRead = 4;
       }
        
        //humidity read
        if (sensorBuffer != lastSensor) {
            lastSensor = sensorBuffer;
            hum_read = (uint16_t)((sensorBuffer >> 16) & 0x00003FFF);
            tem_read = (uint16_t)((sensorBuffer >> 2) & 0x00003FFF);
            rhum_val = hum_read * 100 / (pow(2,14) - 2);
            temp_val = tem_read * 165 / (pow(2,14) - 2) - 40;
            newRead = 2;
        }

        if (windReady == 1) {
            if (angle1 > angle2) {
                angle2 += 360;
            }
            // calculate anemometer angular speed (deg/sec)
            wind_val = (angle2 - angle1) / (delta2 - delta1);
            // convert deg/sec to mi/hr
            newRead = 1;
        }

        //handling of incoming msgs
        if (msg_complete == 1) {
            if (msg[2] == IA || msg[3] == IA) { //checks for subsystem msgs
                //printf("AZia5subsystem ID matchYB");
                clearString();
            } else if (msg[2] != AG && msg[2] != AC && msg[2] != KD && msg[2] != IA) { //checks if sender is in system
                //printf("AZia5unknown sender IDYB");
                clearString();
            } else if (msg[3] == AG || msg[3] == AC || msg[3] == KD || msg[3] == EE) { //checks for msgs to forward
                printf("%s",msg);
                clearString();
            } else { //deletes all other cases
                //printf("AZia5irrelevant msgYB");
                clearString();
            }
            msg_complete = 0;
        }
    }
}