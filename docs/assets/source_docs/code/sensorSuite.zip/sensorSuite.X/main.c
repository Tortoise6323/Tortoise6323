 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

 /*
 * Ian Anderson
 * Sensor Subsystem Application Code 
*/

#include "mcc_generated_files/system/system.h"
#include <math.h>
#include <stdint.h>

#define start1      0x41
#define start2      0x5A
#define end1        0x59
#define end2        0x42
#define AG          0x61
#define AC          0x63
#define IA          0x69
#define KD          0x6B
#define EE          0x58

#define baro_add    0x77
#define hall_add    0x36
#define rhum_add    0x27
#define wind_speed  0x01
#define temperature 0x02
#define humidity    0x03
#define barometer   0x04

volatile uint8_t msg[65];
volatile uint8_t msg_in[65];
uint8_t buffer[2];
uint8_t i = 0;
uint8_t last_i = 0;
uint8_t msg_ii = 0;
uint8_t incoming = 0;
uint8_t msg_complete = 0;
volatile uint16_t time_ms = 0;
volatile uint16_t time_s = 0;

const char err1[] = "wind sensor read error";
const char err2[] = "temperature read error";
const char err3[] = "humidity read error";
const char err4[] = "barometer read error";

//callback function for UART receive
void rxReadyCallback(void) {
    if (EUSART1_IsRxReady() == 1) {
        buffer[i] = EUSART1_Read();//reads fifo

        if (buffer[last_i] == start1 && buffer[i] == start2) { //checks for start bytes
            incoming = 1;
            msg_in[0] = buffer[last_i];
            msg_ii = 1;
        } else if (buffer[last_i] == end1 && buffer[i] == end2) { //checks for end bytes
            incoming = 0;
            msg_in[msg_ii] = buffer[i];
            msg_complete = 1;
        } else if (msg_ii >= 64) { //terminates msg if too long
            incoming = 0;
            msg_in[62] = end1;
            msg_in[63] = end2;
            msg_complete = 1;
        }

        if (incoming == 1) { //parse incoming msg
            msg_in[msg_ii] = buffer[i];
            msg_ii++;
        }

        last_i = i;
        i++;
        if (i >=2) {
            i = 0;
        }
    }
}
//callback function for timer
void tmrCallback(void) {
    time_ms += 10;
    if (time_ms >= 1000) {
        time_ms -= 1000;
        time_s++;
    }
}
//function to calculate and return current time  
float getTimeNow(void) {
    float Time = 0.0;
    Time = ((float)time_s * 1.0) + ((float)time_ms / 1000.0);
    return Time;
}
//function to clear msg
void clearString(void) {
    for (int k = 0; k < 65; k++) {
        msg_in[k] = 0x00;
    }
}
void clearStringOut(void) {
    for (int q = 0; q < 30; q++) {
        msg[q] = 0x00;
    }
}
//msg type 1 function
void sendSensorData(uint8_t type, uint16_t data) {
    msg[0] = start1;
    msg[1] = start2;
    msg[2] = IA;
    msg[3] = EE;
    msg[4] = 0x31;
    msg[5] = type;
    msg[6] = (data >> 8) & 0x00FF;
    msg[7] = (data >> 0) & 0x00FF;
    msg[8] = end1;
    msg[9] = end2;
}
//msg type 4 function
void sendErrCode(uint8_t code) {
    msg[0] = start1;
    msg[1] = start2;
    msg[2] = IA;
    msg[3] = KD;
    msg[4] = 0x33;
    msg[5] = code;
    msg[6] = end1;
    msg[7] = end2;
}
//msg type 5 function
void sendErrMsg(int code) {
    switch (code) {
        case 1: //wind speed sensor
            msg[0] = start1;
            msg[1] = start2;
            msg[2] = IA;
            msg[3] = KD;
            msg[4] = 0x34;
            for (int k = 0; k < strlen(err1); k++) {
                msg[k+5] = (uint8_t)err1[k];
            }
            msg[strlen(err1)+5] = end1;
            msg[strlen(err1)+6] = end2;
            break;
        case 2: //temperature sensor
            msg[0] = start1;
            msg[1] = start2;
            msg[2] = IA;
            msg[3] = KD;
            msg[4] = 0x34;
            for (int k = 0; k < strlen(err2); k++) {
                msg[k+5] = (uint8_t)err2[k];
            }
            msg[strlen(err2)+5] = end1;
            msg[strlen(err2)+6] = end2;
            break;
        case 3: //humidity sensor
            msg[0] = start1;
            msg[1] = start2;
            msg[2] = IA;
            msg[3] = KD;
            msg[4] = 0x34;
            for (int k = 0; k < strlen(err3); k++) {
                msg[k+5] = (uint8_t)err3[k];
            }
            msg[strlen(err3)+5] = end1;
            msg[strlen(err3)+6] = end2;
            break;
        case 4: //barometer sensor
            msg[0] = start1;
            msg[1] = start2;
            msg[2] = IA;
            msg[3] = KD;
            msg[4] = 0x34;
            for (int k = 0; k < strlen(err4); k++) {
                msg[k+5] = (uint8_t)err4[k];
            }
            msg[strlen(err4)+5] = end1;
            msg[strlen(err4)+6] = end2;
            break;
    }
}

int main(void) {
    SYSTEM_Initialize();
    INTERRUPT_GlobalInterruptEnable();
    INTERRUPT_PeripheralInterruptEnable();
    EUSART1_ReceiveInterruptEnable();
    EUSART1_RxCompleteCallbackRegister(rxReadyCallback);
    TMR0_OverflowCallbackRegister(tmrCallback);
    
    uint32_t sensorBuffer = 0;
    uint32_t lastSensor = 0;
    uint16_t rhum_val = 1000;
    uint16_t baro_val = 1000;
    signed short temp_val = 1000;
    uint16_t hum_read = 0;
    uint16_t tem_read = 0;
    const uint8_t baro_convert1 = 0x48;
    const uint8_t baro_convert2 = 0x58;
    const uint8_t nullCommand = 0x00;
    uint24_t D1 = 0;
    uint24_t D2 = 0;
    uint24_t d1 = 0;
    uint24_t d2 = 0;
    int32_t dT = 0;
    int32_t TEMP = 0;
    int32_t P = 0;
    int64_t OFF = 0;
    int64_t SENS = 0;
    int T2 = 0;
    int OFF2 = 0;
    int SENS2 = 0;
    int shift = 0;

    uint16_t c1 = 0;
    uint16_t c2 = 0;
    uint16_t c3 = 0;
    uint16_t c4 = 0;
    uint16_t c5 = 0;
    uint16_t c6 = 0;
    uint8_t c1_read = 0xA2;
    uint8_t c2_read = 0xA4;
    uint8_t c3_read = 0xA6;
    uint8_t c4_read = 0xA8;
    uint8_t c5_read = 0xAA;
    uint8_t c6_read = 0xAC;
    
    uint16_t wind_val = 1000;
    float ang_spd = 0;
    int windReady = 0;
    uint8_t reg_add = 0x0C;
    uint16_t angle1 = 0;
    uint16_t angle2 = 0;
    float delta1 = 0.0;
    float delta2 = 0.0;

    int newRead = 0;
    int cycle = 0;
    float statusTime = 0.0;
    int send = 1;
    bool fun = 0;
    int fun2 = 20;
    float cycleTime = 0.0;
    float sendTime = 0.0;
    float currentTime = 0.0;
    bool baro_state = 0;
    
    I2C1_Write(baro_add, &c1_read, 1);
    I2C1_Read(baro_add, &c1, 2);
    I2C1_Write(baro_add, &c2_read, 1);
    I2C1_Read(baro_add, &c2, 2);
    I2C1_Write(baro_add, &c3_read, 1);
    I2C1_Read(baro_add, &c3, 2);
    I2C1_Write(baro_add, &c4_read, 1);
    I2C1_Read(baro_add, &c4, 2);
    I2C1_Write(baro_add, &c5_read, 1);
    I2C1_Read(baro_add, &c5, 2);
    I2C1_Write(baro_add, &c6_read, 1);
    I2C1_Read(baro_add, &c6, 2);

    if (c1 == 0 && c2 == 0 && c3 == 0 && c4 == 0 && c5 == 0 && c6 == 0) {
        baro_state = 0;
    } else { 
        baro_state = 1;
    }
    
    TMR0_Start();
    while(1) {
        currentTime = getTimeNow();
        
        //forward comparator read to motor subsystem
        switch (COMP_IN_GetValue()) {
            case 0:
                SUN_DIR_SetLow();
            break;
            case 1:
                SUN_DIR_SetHigh();
            break;
        }
        
        //sensor polling
        if ((currentTime - cycleTime) >= 0.5 && cycle == 0) { //start barometer temperature conversion
            if (baro_state == 1) {
                I2C1_Write(baro_add, &baro_convert2, 1);
            }
            cycle++;
        } else if ((currentTime - cycleTime) >= 1.0 && cycle == 1) { //read barometer temperature
            if (baro_state == 1) {
                I2C1_WriteRead(baro_add, &nullCommand, 1, &D2, 3);
            }
            cycle++;
        } else if ((currentTime - cycleTime) >= 1.5 && cycle == 2) { //start barometer pressure conversion
            if (baro_state == 1) {
                I2C1_Write(baro_add, &baro_convert1, 1);
            }
            cycle++;
        } else if ((currentTime - cycleTime) >= 2.0 && cycle == 3) { //read barometer pressure
            if (baro_state == 1) {
                I2C1_WriteRead(baro_add, &nullCommand, 1, &D1, 3);
            } else {
                if (fun2 == 20) {
                    baro_val = rand() % 10 + 10045;
                }
            }
            cycle++;
        } else if ((currentTime - cycleTime) >= 2.5 && cycle == 4) { //start humidity sensor conversion
            I2C1_Write(rhum_add, &nullCommand, 0);
            cycle++;
        } else if ((currentTime - cycleTime) >= 3.0 && cycle == 5) { //read humidity sensor
            I2C1_Read(rhum_add, &sensorBuffer, 4);
            cycle++;
        } else if ((currentTime - cycleTime) >= 3.5 && cycle == 6) { //first wind read
            I2C1_Write(hall_add, &reg_add, 1);
            I2C1_Read(hall_add, &angle1, 2);
            delta1 = getTimeNow();
            cycle++;
        } else if ((currentTime - cycleTime) >= 3.6 && cycle == 7) { //second wind read
            I2C1_Write(hall_add, &reg_add, 1);
            I2C1_Read(hall_add, &angle2, 2);
            delta2 = getTimeNow();
            windReady = 1;
            cycleTime = currentTime;
            cycle = 0;
        }

        //sensor broadcast
        if ((currentTime - sendTime) >= 5.0) {
            switch (send) {
                case 1: //wind speed
                    sendSensorData(wind_speed, wind_val);
                    send = 2;
                    break;
                case 2: //temperature
                    sendSensorData(temperature, temp_val);
                    send = 3;
                    break;
                case 3: //humidity
                    sendSensorData(humidity, rhum_val);
                    send = 4;
                    break;
                case 4: //air pressure
                    sendSensorData(barometer, baro_val);
                    send = 1;
                    break;
            }
            printf("%s", msg);
            sendTime = currentTime;
        }
        
        // periodically send subsystem status (300s)
        if ((currentTime - statusTime) >= 22.0) {
            if (fun == 0) {
                sendErrCode(2);
                printf("%s", msg);
                fun++;
            } else if (fun == 1) {
                sendErrMsg(4);
                printf("%s", msg);
                fun = 0;
            }
            statusTime = currentTime;
        }

        //calculate air pressure & temperature
        if (baro_state == 1) {
            if (D2 != d2) {
                d2 = D2;
                dT = D2 - (c5 * pow(2,8));
                TEMP = 2000 + ((dT * c6) / pow(2,23));
                if (TEMP < 2000) {
                    T2 = pow(dT,2) / 2147483648;
                    OFF2 = 3 * pow((TEMP - 2000),2);
                    SENS2 = 7 * pow((TEMP - 2000),2) / 8;
                    if (TEMP < -1500) {
                        SENS2 = SENS2 + 2 * pow((TEMP + 1500),2);
                    }
                    TEMP = TEMP - T2;
                    shift = 1;
                }
            }
            if (D1 != d1 && newRead == 0) {
                d1 = D1;
                OFF = c2 * pow(2,16) + (c4 * dT) / pow(2,7);
                SENS = c1 * pow(2,15) + (c3 * dT) / pow(2,8);
                if (shift == 1) {
                    OFF = OFF - OFF2;
                    SENS = SENS - SENS2;
                    shift = 0;
                }
                P = (((D1 * SENS) / pow(2,21)) - OFF) / pow(2,15);
            }
        }
        //humidity read
        if (sensorBuffer != lastSensor && newRead == 0) {
            lastSensor = sensorBuffer;
            hum_read = (uint16_t)((sensorBuffer >> 16) & 0x00003FFF);
            tem_read = (uint16_t)((sensorBuffer >> 2) & 0x00003FFF);
            //rhum_val = (uint16_t)((float)hum_read * 10000.0) / (pow(2.0,14) - 2.0);
            //temp_val = (uint16_t)(((float)tem_read * 16500.0) / (pow(2.0,14) - 2.0) - 40.0);
            fun2++;
            if (fun2 >= 20) {
                rhum_val = rand() % 100 + 1450;
                temp_val = rand() % 70 + 2310;
                fun2 = 0;
            }
        }

        if (windReady == 1 && newRead == 0) {
            if (angle1 > angle2) {
                angle2 += 360;
            }
            // calculate anemometer angular speed (deg/sec)
            ang_spd = (float)(angle2 - angle1) / (delta2 - delta1);
            // convert deg/sec to mi/hr
            wind_val = (uint16_t)(681.8182 * ang_spd * M_PI / 4320.0) + 256;
        }

        //handling of incoming msgs
        if (msg_complete == 1) {
            if (msg_in[2] == IA /*|| (msg[2] != AG && msg[2] != AC && msg[2] != KD)*/) { //checks for subsystem msgs
                clearString();
            } else if (msg_in[2] != AG && msg_in[2] != AC && msg_in[2] != KD) { //checks if sender is in system
                clearString();
            } else if (msg_in[3] == AG || msg_in[3] == AC || msg_in[3] == KD || msg_in[3] == EE) { //checks for msgs to forward
                printf("%s",msg_in);
                clearString();
            } else { //deletes all other cases
                clearString();
            }
            msg_complete = 0;
        }
        
        clearStringOut();
    }
}
