/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA0 aliases
#define led1_TRIS                 TRISAbits.TRISA0
#define led1_LAT                  LATAbits.LATA0
#define led1_PORT                 PORTAbits.RA0
#define led1_WPU                  WPUAbits.WPUA0
#define led1_OD                   ODCONAbits.ODCA0
#define led1_ANS                  ANSELAbits.ANSELA0
#define led1_SetHigh()            do { LATAbits.LATA0 = 1; } while(0)
#define led1_SetLow()             do { LATAbits.LATA0 = 0; } while(0)
#define led1_Toggle()             do { LATAbits.LATA0 = ~LATAbits.LATA0; } while(0)
#define led1_GetValue()           PORTAbits.RA0
#define led1_SetDigitalInput()    do { TRISAbits.TRISA0 = 1; } while(0)
#define led1_SetDigitalOutput()   do { TRISAbits.TRISA0 = 0; } while(0)
#define led1_SetPullup()          do { WPUAbits.WPUA0 = 1; } while(0)
#define led1_ResetPullup()        do { WPUAbits.WPUA0 = 0; } while(0)
#define led1_SetPushPull()        do { ODCONAbits.ODCA0 = 0; } while(0)
#define led1_SetOpenDrain()       do { ODCONAbits.ODCA0 = 1; } while(0)
#define led1_SetAnalogMode()      do { ANSELAbits.ANSELA0 = 1; } while(0)
#define led1_SetDigitalMode()     do { ANSELAbits.ANSELA0 = 0; } while(0)

// get/set RA1 aliases
#define led2_TRIS                 TRISAbits.TRISA1
#define led2_LAT                  LATAbits.LATA1
#define led2_PORT                 PORTAbits.RA1
#define led2_WPU                  WPUAbits.WPUA1
#define led2_OD                   ODCONAbits.ODCA1
#define led2_ANS                  ANSELAbits.ANSELA1
#define led2_SetHigh()            do { LATAbits.LATA1 = 1; } while(0)
#define led2_SetLow()             do { LATAbits.LATA1 = 0; } while(0)
#define led2_Toggle()             do { LATAbits.LATA1 = ~LATAbits.LATA1; } while(0)
#define led2_GetValue()           PORTAbits.RA1
#define led2_SetDigitalInput()    do { TRISAbits.TRISA1 = 1; } while(0)
#define led2_SetDigitalOutput()   do { TRISAbits.TRISA1 = 0; } while(0)
#define led2_SetPullup()          do { WPUAbits.WPUA1 = 1; } while(0)
#define led2_ResetPullup()        do { WPUAbits.WPUA1 = 0; } while(0)
#define led2_SetPushPull()        do { ODCONAbits.ODCA1 = 0; } while(0)
#define led2_SetOpenDrain()       do { ODCONAbits.ODCA1 = 1; } while(0)
#define led2_SetAnalogMode()      do { ANSELAbits.ANSELA1 = 1; } while(0)
#define led2_SetDigitalMode()     do { ANSELAbits.ANSELA1 = 0; } while(0)

// get/set RA2 aliases
#define led3_TRIS                 TRISAbits.TRISA2
#define led3_LAT                  LATAbits.LATA2
#define led3_PORT                 PORTAbits.RA2
#define led3_WPU                  WPUAbits.WPUA2
#define led3_OD                   ODCONAbits.ODCA2
#define led3_ANS                  ANSELAbits.ANSELA2
#define led3_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define led3_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define led3_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define led3_GetValue()           PORTAbits.RA2
#define led3_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define led3_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define led3_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define led3_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define led3_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define led3_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define led3_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define led3_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set RA6 aliases
#define UP_CTS_TRIS                 TRISAbits.TRISA6
#define UP_CTS_LAT                  LATAbits.LATA6
#define UP_CTS_PORT                 PORTAbits.RA6
#define UP_CTS_WPU                  WPUAbits.WPUA6
#define UP_CTS_OD                   ODCONAbits.ODCA6
#define UP_CTS_ANS                  ANSELAbits.ANSELA6
#define UP_CTS_SetHigh()            do { LATAbits.LATA6 = 1; } while(0)
#define UP_CTS_SetLow()             do { LATAbits.LATA6 = 0; } while(0)
#define UP_CTS_Toggle()             do { LATAbits.LATA6 = ~LATAbits.LATA6; } while(0)
#define UP_CTS_GetValue()           PORTAbits.RA6
#define UP_CTS_SetDigitalInput()    do { TRISAbits.TRISA6 = 1; } while(0)
#define UP_CTS_SetDigitalOutput()   do { TRISAbits.TRISA6 = 0; } while(0)
#define UP_CTS_SetPullup()          do { WPUAbits.WPUA6 = 1; } while(0)
#define UP_CTS_ResetPullup()        do { WPUAbits.WPUA6 = 0; } while(0)
#define UP_CTS_SetPushPull()        do { ODCONAbits.ODCA6 = 0; } while(0)
#define UP_CTS_SetOpenDrain()       do { ODCONAbits.ODCA6 = 1; } while(0)
#define UP_CTS_SetAnalogMode()      do { ANSELAbits.ANSELA6 = 1; } while(0)
#define UP_CTS_SetDigitalMode()     do { ANSELAbits.ANSELA6 = 0; } while(0)

// get/set RA7 aliases
#define UP_RTS_TRIS                 TRISAbits.TRISA7
#define UP_RTS_LAT                  LATAbits.LATA7
#define UP_RTS_PORT                 PORTAbits.RA7
#define UP_RTS_WPU                  WPUAbits.WPUA7
#define UP_RTS_OD                   ODCONAbits.ODCA7
#define UP_RTS_ANS                  ANSELAbits.ANSELA7
#define UP_RTS_SetHigh()            do { LATAbits.LATA7 = 1; } while(0)
#define UP_RTS_SetLow()             do { LATAbits.LATA7 = 0; } while(0)
#define UP_RTS_Toggle()             do { LATAbits.LATA7 = ~LATAbits.LATA7; } while(0)
#define UP_RTS_GetValue()           PORTAbits.RA7
#define UP_RTS_SetDigitalInput()    do { TRISAbits.TRISA7 = 1; } while(0)
#define UP_RTS_SetDigitalOutput()   do { TRISAbits.TRISA7 = 0; } while(0)
#define UP_RTS_SetPullup()          do { WPUAbits.WPUA7 = 1; } while(0)
#define UP_RTS_ResetPullup()        do { WPUAbits.WPUA7 = 0; } while(0)
#define UP_RTS_SetPushPull()        do { ODCONAbits.ODCA7 = 0; } while(0)
#define UP_RTS_SetOpenDrain()       do { ODCONAbits.ODCA7 = 1; } while(0)
#define UP_RTS_SetAnalogMode()      do { ANSELAbits.ANSELA7 = 1; } while(0)
#define UP_RTS_SetDigitalMode()     do { ANSELAbits.ANSELA7 = 0; } while(0)
#define RA7_SetInterruptHandler  UP_RTS_SetInterruptHandler

// get/set RC0 aliases
#define UART_RX_TRIS                 TRISCbits.TRISC0
#define UART_RX_LAT                  LATCbits.LATC0
#define UART_RX_PORT                 PORTCbits.RC0
#define UART_RX_WPU                  WPUCbits.WPUC0
#define UART_RX_OD                   ODCONCbits.ODCC0
#define UART_RX_ANS                  ANSELCbits.ANSELC0
#define UART_RX_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define UART_RX_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define UART_RX_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define UART_RX_GetValue()           PORTCbits.RC0
#define UART_RX_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define UART_RX_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define UART_RX_SetPullup()          do { WPUCbits.WPUC0 = 1; } while(0)
#define UART_RX_ResetPullup()        do { WPUCbits.WPUC0 = 0; } while(0)
#define UART_RX_SetPushPull()        do { ODCONCbits.ODCC0 = 0; } while(0)
#define UART_RX_SetOpenDrain()       do { ODCONCbits.ODCC0 = 1; } while(0)
#define UART_RX_SetAnalogMode()      do { ANSELCbits.ANSELC0 = 1; } while(0)
#define UART_RX_SetDigitalMode()     do { ANSELCbits.ANSELC0 = 0; } while(0)

// get/set RC1 aliases
#define UART_TX_TRIS                 TRISCbits.TRISC1
#define UART_TX_LAT                  LATCbits.LATC1
#define UART_TX_PORT                 PORTCbits.RC1
#define UART_TX_WPU                  WPUCbits.WPUC1
#define UART_TX_OD                   ODCONCbits.ODCC1
#define UART_TX_ANS                  ANSELCbits.ANSELC1
#define UART_TX_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define UART_TX_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define UART_TX_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define UART_TX_GetValue()           PORTCbits.RC1
#define UART_TX_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define UART_TX_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define UART_TX_SetPullup()          do { WPUCbits.WPUC1 = 1; } while(0)
#define UART_TX_ResetPullup()        do { WPUCbits.WPUC1 = 0; } while(0)
#define UART_TX_SetPushPull()        do { ODCONCbits.ODCC1 = 0; } while(0)
#define UART_TX_SetOpenDrain()       do { ODCONCbits.ODCC1 = 1; } while(0)
#define UART_TX_SetAnalogMode()      do { ANSELCbits.ANSELC1 = 1; } while(0)
#define UART_TX_SetDigitalMode()     do { ANSELCbits.ANSELC1 = 0; } while(0)

// get/set RC2 aliases
#define DO_RTS_TRIS                 TRISCbits.TRISC2
#define DO_RTS_LAT                  LATCbits.LATC2
#define DO_RTS_PORT                 PORTCbits.RC2
#define DO_RTS_WPU                  WPUCbits.WPUC2
#define DO_RTS_OD                   ODCONCbits.ODCC2
#define DO_RTS_ANS                  ANSELCbits.ANSELC2
#define DO_RTS_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define DO_RTS_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define DO_RTS_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define DO_RTS_GetValue()           PORTCbits.RC2
#define DO_RTS_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define DO_RTS_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define DO_RTS_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define DO_RTS_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define DO_RTS_SetPushPull()        do { ODCONCbits.ODCC2 = 0; } while(0)
#define DO_RTS_SetOpenDrain()       do { ODCONCbits.ODCC2 = 1; } while(0)
#define DO_RTS_SetAnalogMode()      do { ANSELCbits.ANSELC2 = 1; } while(0)
#define DO_RTS_SetDigitalMode()     do { ANSELCbits.ANSELC2 = 0; } while(0)

// get/set RC3 aliases
#define DO_CTS_TRIS                 TRISCbits.TRISC3
#define DO_CTS_LAT                  LATCbits.LATC3
#define DO_CTS_PORT                 PORTCbits.RC3
#define DO_CTS_WPU                  WPUCbits.WPUC3
#define DO_CTS_OD                   ODCONCbits.ODCC3
#define DO_CTS_ANS                  ANSELCbits.ANSELC3
#define DO_CTS_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define DO_CTS_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define DO_CTS_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define DO_CTS_GetValue()           PORTCbits.RC3
#define DO_CTS_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define DO_CTS_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define DO_CTS_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define DO_CTS_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define DO_CTS_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define DO_CTS_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define DO_CTS_SetAnalogMode()      do { ANSELCbits.ANSELC3 = 1; } while(0)
#define DO_CTS_SetDigitalMode()     do { ANSELCbits.ANSELC3 = 0; } while(0)

// get/set RC4 aliases
#define SUN_DIR_TRIS                 TRISCbits.TRISC4
#define SUN_DIR_LAT                  LATCbits.LATC4
#define SUN_DIR_PORT                 PORTCbits.RC4
#define SUN_DIR_WPU                  WPUCbits.WPUC4
#define SUN_DIR_OD                   ODCONCbits.ODCC4
#define SUN_DIR_ANS                  ANSELCbits.ANSELC4
#define SUN_DIR_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define SUN_DIR_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define SUN_DIR_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define SUN_DIR_GetValue()           PORTCbits.RC4
#define SUN_DIR_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define SUN_DIR_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define SUN_DIR_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define SUN_DIR_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define SUN_DIR_SetPushPull()        do { ODCONCbits.ODCC4 = 0; } while(0)
#define SUN_DIR_SetOpenDrain()       do { ODCONCbits.ODCC4 = 1; } while(0)
#define SUN_DIR_SetAnalogMode()      do { ANSELCbits.ANSELC4 = 1; } while(0)
#define SUN_DIR_SetDigitalMode()     do { ANSELCbits.ANSELC4 = 0; } while(0)

// get/set RC5 aliases
#define I2C_CLK_TRIS                 TRISCbits.TRISC5
#define I2C_CLK_LAT                  LATCbits.LATC5
#define I2C_CLK_PORT                 PORTCbits.RC5
#define I2C_CLK_WPU                  WPUCbits.WPUC5
#define I2C_CLK_OD                   ODCONCbits.ODCC5
#define I2C_CLK_ANS                  ANSELCbits.ANSELC5
#define I2C_CLK_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define I2C_CLK_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define I2C_CLK_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define I2C_CLK_GetValue()           PORTCbits.RC5
#define I2C_CLK_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define I2C_CLK_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define I2C_CLK_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define I2C_CLK_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define I2C_CLK_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define I2C_CLK_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define I2C_CLK_SetAnalogMode()      do { ANSELCbits.ANSELC5 = 1; } while(0)
#define I2C_CLK_SetDigitalMode()     do { ANSELCbits.ANSELC5 = 0; } while(0)

// get/set RC6 aliases
#define I2C_DAT_TRIS                 TRISCbits.TRISC6
#define I2C_DAT_LAT                  LATCbits.LATC6
#define I2C_DAT_PORT                 PORTCbits.RC6
#define I2C_DAT_WPU                  WPUCbits.WPUC6
#define I2C_DAT_OD                   ODCONCbits.ODCC6
#define I2C_DAT_ANS                  ANSELCbits.ANSELC6
#define I2C_DAT_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define I2C_DAT_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define I2C_DAT_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define I2C_DAT_GetValue()           PORTCbits.RC6
#define I2C_DAT_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define I2C_DAT_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define I2C_DAT_SetPullup()          do { WPUCbits.WPUC6 = 1; } while(0)
#define I2C_DAT_ResetPullup()        do { WPUCbits.WPUC6 = 0; } while(0)
#define I2C_DAT_SetPushPull()        do { ODCONCbits.ODCC6 = 0; } while(0)
#define I2C_DAT_SetOpenDrain()       do { ODCONCbits.ODCC6 = 1; } while(0)
#define I2C_DAT_SetAnalogMode()      do { ANSELCbits.ANSELC6 = 1; } while(0)
#define I2C_DAT_SetDigitalMode()     do { ANSELCbits.ANSELC6 = 0; } while(0)

// get/set RC7 aliases
#define COMP_IN_TRIS                 TRISCbits.TRISC7
#define COMP_IN_LAT                  LATCbits.LATC7
#define COMP_IN_PORT                 PORTCbits.RC7
#define COMP_IN_WPU                  WPUCbits.WPUC7
#define COMP_IN_OD                   ODCONCbits.ODCC7
#define COMP_IN_ANS                  ANSELCbits.ANSELC7
#define COMP_IN_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define COMP_IN_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define COMP_IN_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define COMP_IN_GetValue()           PORTCbits.RC7
#define COMP_IN_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define COMP_IN_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define COMP_IN_SetPullup()          do { WPUCbits.WPUC7 = 1; } while(0)
#define COMP_IN_ResetPullup()        do { WPUCbits.WPUC7 = 0; } while(0)
#define COMP_IN_SetPushPull()        do { ODCONCbits.ODCC7 = 0; } while(0)
#define COMP_IN_SetOpenDrain()       do { ODCONCbits.ODCC7 = 1; } while(0)
#define COMP_IN_SetAnalogMode()      do { ANSELCbits.ANSELC7 = 1; } while(0)
#define COMP_IN_SetDigitalMode()     do { ANSELCbits.ANSELC7 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handler for the UP_RTS pin functionality
 * @param none
 * @return none
 */
void UP_RTS_ISR(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for UP_RTS pin interrupt-on-change functionality.
 *        Allows selecting an interrupt handler for UP_RTS at application runtime
 * @pre Pins intializer called
 * @param InterruptHandler function pointer.
 * @return none
 */
void UP_RTS_SetInterruptHandler(void (* InterruptHandler)(void));

/**
 * @ingroup  pinsdriver
 * @brief Dynamic Interrupt Handler for UP_RTS pin.
 *        This is a dynamic interrupt handler to be used together with the UP_RTS_SetInterruptHandler() method.
 *        This handler is called every time the UP_RTS ISR is executed and allows any function to be registered at runtime.
 * @pre Pins intializer called
 * @param none
 * @return none
 */
extern void (*UP_RTS_InterruptHandler)(void);

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for UP_RTS pin. 
 *        This is a predefined interrupt handler to be used together with the UP_RTS_SetInterruptHandler() method.
 *        This handler is called every time the UP_RTS ISR is executed. 
 * @pre Pins intializer called
 * @param none
 * @return none
 */
void UP_RTS_DefaultInterruptHandler(void);


#endif // PINS_H
/**
 End of File
*/