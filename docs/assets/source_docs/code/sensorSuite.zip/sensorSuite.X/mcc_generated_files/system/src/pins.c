/**
 * Generated Driver File
 * 
 * @file pins.c
 * 
 * @ingroup  pinsdriver
 * 
 * @brief This is generated driver implementation for pins. 
 *        This file provides implementations for pin APIs for all pins selected in the GUI.
 *
 * @version Driver Version 3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#include "../pins.h"

void (*UP_RTS_InterruptHandler)(void);

void PIN_MANAGER_Initialize(void)
{
   /**
    LATx registers
    */
    LATA = 0x0;
    LATB = 0x0;
    LATC = 0x60;
    /**
    ODx registers
    */
    ODCONA = 0x0;
    ODCONB = 0x0;
    ODCONC = 0x0;

    /**
    TRISx registers
    */
    TRISA = 0xB8;
    TRISB = 0xFF;
    TRISC = 0xE9;

    /**
    ANSELx registers
    */
    ANSELA = 0x38;
    ANSELB = 0xFF;
    ANSELC = 0x0;

    /**
    WPUx registers
    */
    WPUA = 0x0;
    WPUB = 0x0;
    WPUC = 0x0;
    WPUE = 0x0;


    /**
    SLRCONx registers
    */
    SLRCONA = 0xFF;
    SLRCONB = 0xFF;
    SLRCONC = 0xFF;

    /**
    INLVLx registers
    */
    INLVLA = 0xFF;
    INLVLB = 0xFF;
    INLVLC = 0xFF;
    INLVLE = 0x8;

   /**
    RxyI2C | RxyFEAT registers   
    */
    /**
    PPS registers
    */
    RX1PPS = 0x10; //RC0->EUSART1:RX1;
    RC1PPS = 0x09;  //RC1->EUSART1:TX1;
    SSP1CLKPPS = 0x15;  //RC5->MSSP1:SCL1;
    RC5PPS = 0x0F;  //RC5->MSSP1:SCL1;
    SSP1DATPPS = 0x16;  //RC6->MSSP1:SDA1;
    RC6PPS = 0x10;  //RC6->MSSP1:SDA1;

   /**
    IOCx registers 
    */
    IOCAP = 0x80;
    IOCAN = 0x0;
    IOCAF = 0x0;
    IOCBP = 0x0;
    IOCBN = 0x0;
    IOCBF = 0x0;
    IOCCP = 0x0;
    IOCCN = 0x0;
    IOCCF = 0x0;
    IOCEP = 0x0;
    IOCEN = 0x0;
    IOCEF = 0x0;

    UP_RTS_SetInterruptHandler(UP_RTS_DefaultInterruptHandler);

    // Enable PIE0bits.IOCIE interrupt 
    PIE0bits.IOCIE = 1; 
}
  
void PIN_MANAGER_IOC(void)
{
    // interrupt on change for pin UP_RTS
    if(IOCAFbits.IOCAF7 == 1)
    {
        UP_RTS_ISR();  
    }
}
   
/**
   UP_RTS Interrupt Service Routine
*/
void UP_RTS_ISR(void) {

    // Add custom UP_RTS code

    // Call the interrupt handler for the callback registered at runtime
    if(UP_RTS_InterruptHandler)
    {
        UP_RTS_InterruptHandler();
    }
    IOCAFbits.IOCAF7 = 0;
}

/**
  Allows selecting an interrupt handler for UP_RTS at application runtime
*/
void UP_RTS_SetInterruptHandler(void (* InterruptHandler)(void)){
    UP_RTS_InterruptHandler = InterruptHandler;
}

/**
  Default interrupt handler for UP_RTS
*/
void UP_RTS_DefaultInterruptHandler(void){
    // add your UP_RTS interrupt custom code
    // or set custom function using UP_RTS_SetInterruptHandler()
}
/**
 End of File
*/